"""Metrics should remain easy to inspect on tiny hand-checked examples."""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from cultural_speech.decode import prefix_beam_search
from cultural_speech.metrics import (corpus_bleu2, error_rate, generation_metrics,
                                     intent_metrics, mean_sd_ci, rouge_l_f1)
import torch


def test_error_rate_and_intent():
    assert error_rate([("\u4f60\u597d", "\u4f60\u53f7")]) == 0.5
    assert error_rate([("\u4f60\u597d", "\u4f60\u597d")]) == 0
    report = intent_metrics([0, 1, 2], [0, 1, 2])
    assert report["accuracy"] == 1.0
    assert report["macro_f1"] == 1.0


def test_text_metrics():
    assert abs(corpus_bleu2(["\u6625\u98ce\u79cb\u6708"], ["\u6625\u98ce\u79cb\u6708"]) - 100.0) < 1e-8
    assert abs(rouge_l_f1(["\u6625\u98ce\u79cb\u6708"], ["\u6625\u98ce\u79cb\u6708"]) - 100.0) < 1e-8
    assert generation_metrics(["\u6587\u5316\u6545\u4e8b"], ["\u6587\u5316\u6545\u4e8b"])["bertscore_f1"] is None


def test_ctc_beam_and_confidence():
    logp = torch.tensor([[0.05, 0.90, 0.05], [0.90, 0.05, 0.05]]).log()
    candidates = prefix_beam_search(logp, blank_id=0, width=3)
    assert candidates[0][0] == [1]
    assert mean_sd_ci([1, 2, 3])["mean"] == 2.0
