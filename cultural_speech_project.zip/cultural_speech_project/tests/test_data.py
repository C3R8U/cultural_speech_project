"""Manifests should identify test fixtures and resolve local audio paths safely."""

import json
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from cultural_speech.dataset import load_records


def test_demo_needs_explicit_permission():
    path = ROOT / "examples" / "synthetic_demo" / "train.jsonl"
    with pytest.raises(ValueError):
        load_records(path)
    records = load_records(path, allowed_origins=("synthetic_demo",))
    assert len(records) == 3
    assert all(Path(r["audio_path"]).is_file() for r in records)


def test_ids_are_unique():
    path = ROOT / "examples" / "synthetic_demo" / "train.jsonl"
    records = load_records(path, allowed_origins=("synthetic_demo",))
    assert len({r["sample_id"] for r in records}) == len(records)
