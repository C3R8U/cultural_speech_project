"""Basic numerical checks for acoustic and semantic data flow."""

import sys
from pathlib import Path

import torch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from cultural_speech.model import BlankAwareBridge, JointSpeechSemanticModel


def tiny_config():
    return {
        "acoustic_layers": 3, "acoustic_hidden_per_direction": 8,
        "semantic_layers": 2, "semantic_hidden": 12, "embedding_dim": 16,
        "generation_layers": 2, "generation_hidden": 12, "dropout": 0.10,
        "ctc_blank_id": 0,
    }


def test_bridge_masks_blank_frames():
    bridge = BlankAwareBridge(10, 16)
    probs = torch.full((2, 4, 10), -6.0)
    probs[..., 0] = 4.0
    probs = probs.log_softmax(-1).requires_grad_(True)
    embedded, nonblank = bridge(probs)
    assert embedded.shape == (2, 4, 16)
    assert torch.all(nonblank < 0.01)
    embedded.sum().backward()
    assert probs.grad is not None


def test_model_joint_loss_gradient():
    model = JointSpeechSemanticModel(20, tiny_config())
    batch = {
        "features": torch.randn(3, 30, 39),
        "feature_lengths": torch.tensor([30, 28, 24]),
        "ctc_targets": torch.tensor([5, 6, 7, 8, 9, 10]),
        "ctc_target_lengths": torch.tensor([2, 2, 2]),
        "intent": torch.tensor([0, 1, 2]),
        "decoder_input": torch.tensor([[2, 5], [2, 6], [2, 7]]),
        "decoder_target": torch.tensor([[5, 3], [6, 3], [7, 3]]),
    }
    output = model(batch)
    assert all(k in output["losses"] for k in ("ctc", "intent", "generation"))
    output["loss"].backward()
    assert model.encoder.weight_ih_l0.grad is not None
    assert model.bridge.embedding.weight.grad is not None
