# Data acquisition and result provenance

This package contains current Python implementations of the sequence modeling, inference, and scoring workflows. It does not establish that these files were the original files used to generate previously reported study results. No claim of historical identity or original experiment provenance is made.

## Recorded and public collections

- AISHELL-1: https://www.openslr.org/33/ (official 15 GB archive; download separately).
- Common Voice Chinese v16: https://huggingface.co/datasets/fsicoli/common_voice_16_0 (unofficial mirror; confirm Chinese locale and upstream version). The curated 36/4/4-hour split is not publicly identified by this link.
- THUCNews: https://github.com/thunlp/THUCTC (text classifier project; the original THUCNews corpus has a separate access route).
- Chinese Poetry: https://github.com/chinese-poetry/chinese-poetry (poetry data in JSON files; curated 50k/5k/5k sequence split must be documented).
- Field-Culture Test: https://github.com/C3R8U/Field-Culture-Test (a task manifest and research package are visible; the presence of original recorded WAV and transcripts has not been confirmed).
- CSSP: original local dataset must be obtained from its authorized custodian. A Windows path on another computer is not accessible from this environment.

All audio manifests must point to actual existing files. Private recordings should only be handled under valid consent, institutional policies, and any required controlled-access agreement.

## Experiment-specific files

An actual model evaluation requires the original manifest, manual reference transcripts, speaker-disjoint split definitions, model parameters, and checkpoint files. Per-sample prediction records and subject ratings are needed to independently verify objective scores and statistical claims. These files cannot be manufactured from published summary statistics.

Generated electronic tones under `examples/synthetic_demo/` are explicitly identified as software test fixtures. They are not speech recordings, cultural participant observations, or a substitute for the original experiments. Results obtained from them are not scientific evidence for reported corpus metrics.

## Example commands

```bash
python scripts/prepare_corpora.py aishell --root /datasets/aishell --output data/manifests
python scripts/prepare_corpora.py common_voice --root /datasets/cv_16_zh --output data/manifests
# Optional mirror streaming: python scripts/stream_common_voice.py --locale zh-CN --output data/common_voice_stream
python scripts/prepare_corpora.py cultural --dataset CSSP --csv /private/cssp.csv --audio-root /private/cssp_audio --output data/manifests
python scripts/prepare_corpora.py cultural --dataset 'Field-Culture Test' --csv /private/field.csv --audio-root /private/field_audio --output data/manifests
python scripts/prepare_corpora.py thucnews --root /datasets/THUCNews --output data/text
python scripts/prepare_corpora.py poetry --root /datasets/chinese-poetry --output data/text
python scripts/validate_data.py data/manifests/cssp_train.jsonl data/manifests/cssp_dev.jsonl data/manifests/cssp_test.jsonl --output artifacts/data_validation.json
python scripts/pretrain_auxiliary.py --config configs/paper.yaml --thucnews data/text/thucnews_train.jsonl --poetry data/text/poetry_train.jsonl --speech-manifest data/manifests/cssp_train.jsonl --output runs/aux
python scripts/train.py --config configs/paper.yaml --train data/manifests/cssp_train.jsonl --validation data/manifests/cssp_dev.jsonl --initial-checkpoint runs/aux/auxiliary.pt --seed 17 --output runs/seed17
python scripts/tune_rerank.py --checkpoint runs/seed17/best.pt --validation data/manifests/cssp_dev.jsonl --output runs/seed17/rerank.json
python scripts/evaluate.py --checkpoint runs/seed17/best.pt --test data/manifests/cssp_test.jsonl --rerank-config runs/seed17/rerank.json --output runs/seed17/cssp_test
python scripts/evaluate.py --checkpoint runs/seed17/best.pt --test data/manifests/field_culture_test.jsonl --rerank-config runs/seed17/rerank.json --output runs/seed17/field_test
python scripts/aggregate_seeds.py runs/seed*/cssp_test/evaluation.json --metric wer --output artifacts/wer_summary.json
```

The configured word-error rate uses Jieba word segmentation and the character-error rate uses individual characters. These conventions must be reported explicitly. Character BLEU-2 and character ROUGE-L are distinct from alternative tokenization conventions.

The 95% seed confidence interval uses the Student t distribution. The program will not output a confidence interval from a single training seed.

The semantic re-ranking coefficient is not numerically specified in the source manuscript. The paper configuration leaves it unset until it is selected on validation audio. The smoke configuration uses an explicitly illustrative coefficient solely for code execution checks.
