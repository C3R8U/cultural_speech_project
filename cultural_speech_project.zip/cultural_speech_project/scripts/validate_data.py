"""Check sample identity, recording availability, and split separation."""

import argparse
import collections
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from cultural_speech.config import save_json, sha256_file
from cultural_speech.dataset import load_records


def validate(paths, allow_demo=False):
    admitted = ("observed", "public_corpus", "synthetic_demo") if allow_demo else ("observed", "public_corpus")
    all_rows = []
    source_info = []
    for path in paths:
        rows = load_records(path, admitted)
        source_info.append({"path": str(path), "sha256": sha256_file(path), "count": len(rows)})
        all_rows.extend(rows)
    seen = collections.defaultdict(set)
    duplicated = set()
    for record in all_rows:
        seen[record["split"]].add(record["speaker_id"])
        duplicated.add(record["sample_id"])
    for first, speakers in seen.items():
        for second, other in seen.items():
            if first < second and speakers & other:
                raise ValueError(f"Speaker ID overlap between {first} and {second}")
    if len(duplicated) != len(all_rows):
        raise ValueError("Duplicate IDs across input manifests")
    return {"status": "valid", "sources": source_info,
            "counts_by_split": dict(collections.Counter(r["split"] for r in all_rows)),
            "counts_by_origin": dict(collections.Counter(r["origin"] for r in all_rows)),
            "counts_by_dataset": dict(collections.Counter(r["dataset"] for r in all_rows)),
            "counts_by_intent": dict(collections.Counter(r.get("intent") for r in all_rows)),
            "speaker_counts": {k: len(v) for k, v in seen.items()}}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("manifests", nargs="+")
    parser.add_argument("--output", required=True)
    parser.add_argument("--allow-demo", action="store_true")
    args = parser.parse_args()
    result = validate(args.manifests, args.allow_demo)
    save_json(args.output, result)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
