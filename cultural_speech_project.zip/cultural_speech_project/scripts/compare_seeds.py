"""Two-level paired bootstrap for independently seeded speech recognizers."""

import argparse
import json
import sys
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

import numpy as np

from cultural_speech.config import save_json
from cultural_speech.metrics import error_rate, mean_sd_ci


def load_predictions(paths):
    outputs = {}
    for path in paths:
        with open(path, encoding="utf-8") as handle:
            rows = [json.loads(line) for line in handle if line.strip()]
        mapping = {r["sample_id"]: r for r in rows}
        if len(mapping) != len(rows):
            raise ValueError("Duplicate sample identifiers")
        outputs[Path(path).parent.parent.name] = mapping
    return outputs


def compare(system_a, system_b, repetitions, seed):
    if set(system_a) != set(system_b):
        raise ValueError("Seed folders must match between systems")
    seeds = sorted(system_a)
    sample_ids = sorted(next(iter(system_a.values())))
    if not seeds or not sample_ids:
        raise ValueError("Empty model comparison inputs")
    for group in (system_a, system_b):
        for values in group.values():
            if set(values) != set(sample_ids):
                raise ValueError("Every seed must evaluate the same held-out samples")
    observed_a, observed_b = [], []
    for item in seeds:
        observed_a.append(error_rate([(system_a[item][sid]["reference_text"],
                                       system_a[item][sid]["prediction_text"]) for sid in sample_ids]))
        observed_b.append(error_rate([(system_b[item][sid]["reference_text"],
                                       system_b[item][sid]["prediction_text"]) for sid in sample_ids]))
    rng = np.random.default_rng(seed)
    differences = []
    for _ in range(repetitions):
        selected_seeds = rng.choice(seeds, size=len(seeds), replace=True)
        selected_samples = rng.choice(sample_ids, size=len(sample_ids), replace=True)
        rates_a, rates_b = [], []
        for selected_seed in selected_seeds:
            rates_a.append(error_rate([
                (system_a[selected_seed][sid]["reference_text"], system_a[selected_seed][sid]["prediction_text"])
                for sid in selected_samples
            ]))
            rates_b.append(error_rate([
                (system_b[selected_seed][sid]["reference_text"], system_b[selected_seed][sid]["prediction_text"])
                for sid in selected_samples
            ]))
        differences.append(np.mean(rates_a) - np.mean(rates_b))
    values = np.asarray(differences)
    p_value = min(1.0, 2.0 * min(float((values >= 0).mean()), float((values <= 0).mean())))
    return {"system_a": mean_sd_ci(observed_a), "system_b": mean_sd_ci(observed_b),
            "delta_a_minus_b": float(np.mean(values)),
            "bootstrap_ci95": np.quantile(values, [0.025, 0.975]).tolist(),
            "p_value_two_sided": p_value, "resamples": repetitions,
            "seed_count": len(seeds), "sample_count": len(sample_ids),
            "metric": "character_error_rate"}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--system-a", nargs="+", required=True)
    parser.add_argument("--system-b", nargs="+", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--draws", type=int, default=10000)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()
    report = compare(load_predictions(args.system_a), load_predictions(args.system_b),
                     args.draws, args.seed)
    save_json(args.output, report)
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
