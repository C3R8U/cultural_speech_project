"""Train a joint model from verified local audio manifests."""

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from cultural_speech.config import (device_metadata, load_config,
                                    save_json, seed_everything, sha256_file)
from cultural_speech.dataset import SpeechDataset, load_records
from cultural_speech.model import JointSpeechSemanticModel
from cultural_speech.training import train_model
from cultural_speech.vocab import CharacterVocabulary


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--train", required=True)
    parser.add_argument("--validation", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--initial-checkpoint", default=None)
    parser.add_argument("--allow-demo", action="store_true",
                        help="Enable explicitly identified generated test fixtures")
    args = parser.parse_args()
    cfg = load_config(args.config)
    seed_everything(args.seed)
    origins = ("observed", "public_corpus", "synthetic_demo") if args.allow_demo else ("observed", "public_corpus")
    train_records = load_records(args.train, allowed_origins=origins)
    dev_records = load_records(args.validation, allowed_origins=origins)
    if not train_records or not dev_records:
        raise ValueError("Training and validation manifests must not be empty")
    if set(r["speaker_id"] for r in train_records) & set(r["speaker_id"] for r in dev_records):
        raise ValueError("Training and validation speakers overlap")
    origin = "synthetic_demo" if any(r["origin"] == "synthetic_demo" for r in train_records + dev_records) else "observed_or_public"
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    if args.initial_checkpoint:
        initial = torch.load(args.initial_checkpoint, map_location="cpu", weights_only=False)
        vocab = CharacterVocabulary(initial["vocab_tokens"])
    else:
        vocab = CharacterVocabulary.from_texts(
            [r["text"] + r.get("target_text", "") for r in train_records]
        )
    vocab.save(output / "vocab.json")
    source_metadata = {
        "origin": origin,
        "training_manifest_sha256": sha256_file(args.train),
        "validation_manifest_sha256": sha256_file(args.validation),
        "initial_checkpoint": args.initial_checkpoint,
        "training_samples": len(train_records),
        "validation_samples": len(dev_records),
    }
    save_json(output / "execution_metadata.json", {
        "config": cfg, "seed": args.seed, "hardware": device_metadata(),
        "input_sources": source_metadata,
    })
    model = JointSpeechSemanticModel(vocab.size, cfg["model"])
    if args.initial_checkpoint:
        model.load_state_dict(initial["model_state"], strict=True)
    train_model(
        model,
        SpeechDataset(train_records, vocab, cfg["features"]),
        SpeechDataset(dev_records, vocab, cfg["features"]),
        vocab, cfg, output, args.seed, source_metadata,
    )
    print(json.dumps({"output": str(output), **source_metadata}, indent=2))


if __name__ == "__main__":
    main()
