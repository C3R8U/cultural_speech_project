"""Stream an identified Chinese Common Voice locale to local WAV manifests."""

import argparse
import hashlib
import json
import sys
from collections import defaultdict
from pathlib import Path

import librosa
import numpy as np
import soundfile as sf

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from cultural_speech.config import save_json


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", required=True)
    parser.add_argument("--locale", default="zh-CN")
    parser.add_argument("--source-split", default="train")
    parser.add_argument("--max-hours", type=float, default=44.0)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()
    try:
        from datasets import load_dataset
    except ImportError as exc:
        raise RuntimeError("Install the Hugging Face datasets package") from exc
    # This repository uses a custom dataset loader on some datasets releases.
    try:
        source = load_dataset("fsicoli/common_voice_16_0", args.locale,
                              split=args.source_split, streaming=True,
                              trust_remote_code=True)
    except Exception as exc:
        raise RuntimeError(
            "The selected mirror and dataset loader are not compatible or accessible. "
            "Use a downloaded official Common Voice locale archive and prepare_corpora.py instead."
        ) from exc
    root = Path(args.output)
    audio_dir = root / "clips"
    audio_dir.mkdir(parents=True, exist_ok=True)
    targets = {"train": args.max_hours * 36.0 / 44.0,
               "dev": args.max_hours * 4.0 / 44.0,
               "test": args.max_hours * 4.0 / 44.0}
    hours = dict.fromkeys(targets, 0.0)
    manifests = defaultdict(list)
    for index, record in enumerate(source):
        audio = record.get("audio")
        transcript = record.get("sentence", "").strip()
        if not audio or not transcript:
            continue
        wave = np.asarray(audio["array"], dtype=np.float32)
        sample_rate = int(audio["sampling_rate"])
        if wave.ndim != 1:
            continue
        duration = len(wave) / sample_rate
        if not (1.5 <= duration <= 12.0):
            continue
        speaker = str(record.get("client_id") or f"unknown_{index}")
        speaker_hash = hashlib.sha256(f"{speaker}:{args.seed}".encode()).digest()[0] % 44
        split = "train" if speaker_hash < 36 else ("dev" if speaker_hash < 40 else "test")
        if hours[split] + duration / 3600.0 > targets[split]:
            continue
        if sample_rate != 16000:
            wave = librosa.resample(wave, orig_sr=sample_rate, target_sr=16000)
        sample_id = hashlib.sha256(f"{args.locale}:{args.source_split}:{index}".encode()).hexdigest()[:20]
        path = audio_dir / f"{sample_id}.wav"
        sf.write(path, wave, 16000, subtype="PCM_16")
        manifests[split].append({"sample_id": sample_id, "audio_path": f"clips/{path.name}",
                                "speaker_id": speaker, "text": transcript,
                                "dataset": "Common Voice Chinese v16", "origin": "public_corpus",
                                "split": split, "intent": None, "target_text": "",
                                "scenario": record.get("accent"),
                                "duration_seconds": round(duration, 5)})
        hours[split] += duration / 3600.0
        if all(hours[s] >= targets[s] - 12 / 3600 for s in targets):
            break
    for split, records in manifests.items():
        with (root / f"common_voice_{split}.jsonl").open("w", encoding="utf-8") as handle:
            for entry in records:
                handle.write(json.dumps(entry, ensure_ascii=False) + "\n")
    save_json(root / "source_report.json", {
        "dataset": "fsicoli/common_voice_16_0", "locale": args.locale,
        "split": args.source_split, "hours_by_split": hours,
        "required_hours": targets, "seed": args.seed,
        "count_by_split": {k: len(v) for k, v in manifests.items()},
        "selection_method": "speaker_hash_then_duration_cap",
        "original_study_subset_match_claimed": False,
    })
    print(json.dumps(hours, indent=2))


if __name__ == "__main__":
    main()
