"""Schedule independent training runs with isolated checkpoints and logs."""

import argparse
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--train", required=True)
    parser.add_argument("--validation", required=True)
    parser.add_argument("--test", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--initial-checkpoint", default=None)
    parser.add_argument("--seeds", type=int, nargs="+", default=[17, 29, 42, 73, 101])
    parser.add_argument("--allow-demo", action="store_true")
    args = parser.parse_args()
    from cultural_speech.config import load_config
    cfg = load_config(args.config)
    for seed in args.seeds:
        run = Path(args.output) / f"seed_{seed}"
        command = [sys.executable, str(ROOT / "scripts" / "train.py"),
                   "--config", args.config, "--train", args.train,
                   "--validation", args.validation, "--output", str(run),
                   "--seed", str(seed)]
        if args.initial_checkpoint:
            command += ["--initial-checkpoint", args.initial_checkpoint]
        if args.allow_demo:
            command.append("--allow-demo")
        subprocess.run(command, check=True)
        rerank_file = run / "rerank.json"
        if cfg["model"].get("rerank_weight") is None:
            tune = [sys.executable, str(ROOT / "scripts" / "tune_rerank.py"),
                    "--checkpoint", str(run / "best.pt"),
                    "--validation", args.validation, "--output", str(rerank_file)]
            if args.allow_demo:
                tune.append("--allow-demo")
            subprocess.run(tune, check=True)
        evaluation = [sys.executable, str(ROOT / "scripts" / "evaluate.py"),
                      "--checkpoint", str(run / "best.pt"), "--test", args.test,
                      "--output", str(run / "test")]
        if cfg["model"].get("rerank_weight") is None:
            evaluation.extend(["--rerank-config", str(rerank_file)])
        if args.allow_demo:
            evaluation.append("--allow-demo")
        subprocess.run(evaluation, check=True)
    print(json.dumps({"seeds": args.seeds, "runs": len(args.seeds),
                      "output": args.output}, indent=2))


if __name__ == "__main__":
    main()
