"""Language and poetry sequence pretraining for the downstream LSTM modules."""

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

import torch
from torch.nn import functional as F

from cultural_speech.config import (append_jsonl, load_config,
                                    save_json, seed_everything, sha256_file)
from cultural_speech.model import JointSpeechSemanticModel
from cultural_speech.vocab import CharacterVocabulary


def read_texts(paths):
    texts = []
    for path in paths:
        with open(path, encoding="utf-8") as handle:
            for line in handle:
                if not line.strip():
                    continue
                item = json.loads(line)
                if item["origin"] not in ("public_corpus", "observed"):
                    raise ValueError("Language training requires real source observations")
                if item.get("text"):
                    texts.append(item["text"])
    return texts


def make_chunks(text, vocab, block_size):
    ids = vocab.encode(text)[:block_size]
    if len(ids) < 2:
        return None
    return torch.tensor(ids[:-1], dtype=torch.long), torch.tensor(ids[1:], dtype=torch.long)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--thucnews", required=True)
    parser.add_argument("--poetry", required=True)
    parser.add_argument("--speech-manifest", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--epochs", type=int, default=1)
    parser.add_argument("--max-length", type=int, default=128)
    args = parser.parse_args()
    cfg = load_config(args.config)
    seed_everything(args.seed)
    thucnews = read_texts([args.thucnews])
    poetry = read_texts([args.poetry])
    speech = read_texts([args.speech_manifest])
    if not thucnews or not poetry or not speech:
        raise ValueError("Each text source must contain valid text samples")
    vocab = CharacterVocabulary.from_texts(thucnews + poetry + speech)
    model = JointSpeechSemanticModel(vocab.size, cfg["model"])
    semantic_head = torch.nn.Linear(cfg["model"]["semantic_hidden"], vocab.size)
    optimizer_sem = torch.optim.Adam(
        list(model.semantic.parameters()) + list(model.bridge.embedding.parameters()) +
        list(semantic_head.parameters()), lr=cfg["optimization"]["learning_rate"])
    optimizer_gen = torch.optim.Adam(
        list(model.generation.parameters()) + list(model.generation_embedding.parameters()) +
        list(model.generation_init_h.parameters()) + list(model.generation_init_c.parameters()) +
        list(model.generation_head.parameters()), lr=cfg["optimization"]["learning_rate"])
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    for epoch in range(args.epochs):
        for name, texts in (("semantic_language_model", thucnews), ("generation_decoder", poetry)):
            total = 0.0
            n = 0
            for text in texts:
                chunk = make_chunks(text, vocab, args.max_length)
                if chunk is None:
                    continue
                left, right = (x[None, :] for x in chunk)
                if name == "semantic_language_model":
                    inputs = model.bridge.embedding(left)
                    output_seq, _ = model.semantic(inputs)
                    logits = semantic_head(output_seq)
                    optimizer = optimizer_sem
                else:
                    pooled = torch.zeros(1, cfg["model"]["semantic_hidden"])
                    logits = model.generate_logits(pooled, left)
                    optimizer = optimizer_gen
                loss = F.cross_entropy(logits.reshape(-1, vocab.size), right.reshape(-1))
                optimizer.zero_grad()
                loss.backward()
                optimizer.step()
                total += float(loss.detach())
                n += 1
            append_jsonl(output / "auxiliary_training.jsonl",
                         {"epoch": epoch + 1, "task": name, "samples": n,
                          "mean_loss": total / max(1, n), "origin": "public_or_observed"})
    torch.save({"model_state": model.state_dict(), "vocab_tokens": vocab.tokens,
                "config": cfg, "source_metadata": {"origin": "public_or_observed",
                "thucnews_sha256": sha256_file(args.thucnews),
                "poetry_sha256": sha256_file(args.poetry),
                "speech_sha256": sha256_file(args.speech_manifest)}}, output / "auxiliary.pt")
    save_json(output / "auxiliary_summary.json", {
        "count_news": len(thucnews), "count_poetry": len(poetry), "count_speech": len(speech),
        "vocab_size": vocab.size, "epochs": args.epochs,
        "semantic_objective": "character_next_token_prediction",
        "generation_objective": "character_next_token_prediction",
        "origin": "public_or_observed"})
    print(f"Saved auxiliary weights to {output / 'auxiliary.pt'}")


if __name__ == "__main__":
    main()
