"""Summarize independently executed seeds from their saved metric files."""

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from cultural_speech.config import save_json
from cultural_speech.metrics import mean_sd_ci


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("files", nargs="+")
    parser.add_argument("--output", required=True)
    parser.add_argument("--metric", default="wer")
    args = parser.parse_args()
    values = []
    sources = []
    for file in args.files:
        data = json.loads(Path(file).read_text(encoding="utf-8"))
        if data.get(args.metric) is None:
            raise ValueError(f"Missing metric in {file}")
        values.append(data[args.metric])
        sources.append({"path": file, "origin": data.get("origin")})
    report = {"metric": args.metric, "summary": mean_sd_ci(values),
              "values": values, "source_files": sources}
    save_json(args.output, report)
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
