"""Generate a small sound-and-label fixture for pipeline smoke tests."""

import json
from pathlib import Path

import numpy as np
import soundfile as sf


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "examples" / "synthetic_demo"
OUT.mkdir(parents=True, exist_ok=True)

samples = [
    ("train", "demo_speaker_01", "\u6587\u7269", "cultural_inquiry", "\u5386\u53f2", 220),
    ("train", "demo_speaker_02", "\u8bd7\u8bcd", "creative_request", "\u6625\u98ce", 260),
    ("train", "demo_speaker_03", "\u611f\u52a8", "emotional_expression", "\u6587\u5316", 300),
    ("dev", "demo_speaker_04", "\u5de5\u827a", "cultural_inquiry", "\u4f20\u7edf", 330),
    ("dev", "demo_speaker_05", "\u559c\u7231", "emotional_expression", "\u7f8e\u597d", 360),
    ("test", "demo_speaker_06", "\u6545\u4e8b", "creative_request", "\u6587\u5316", 400),
]
for prior in ("train.jsonl", "dev.jsonl", "test.jsonl"):
    (OUT / prior).unlink(missing_ok=True)
rng = np.random.default_rng(42)
for index, (split, speaker, text, intent, target, frequency) in enumerate(samples):
    # These are simple electronic tones, not recorded human utterances.
    sr = 16000
    time_axis = np.arange(sr, dtype=np.float32) / sr
    wave = (0.05 * np.sin(2 * np.pi * frequency * time_axis) +
            0.002 * rng.normal(size=sr)).astype(np.float32)
    wav = OUT / f"tone_{index:03d}.wav"
    sf.write(wav, wave, sr, subtype="PCM_16")
    record = {
        "sample_id": f"synthetic_demo_{index:03d}", "speaker_id": speaker,
        "audio_path": wav.name, "text": text,
        "intent": intent, "target_text": target,
        "scenario": "electronic_tone_test", "dataset": "synthetic_demo",
        "split": split, "origin": "synthetic_demo", "duration_seconds": 1.0,
    }
    with (OUT / f"{split}.jsonl").open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(record, ensure_ascii=False) + "\n")
(OUT / "source_metadata.json").write_text(json.dumps({
    "origin": "synthetic_demo", "purpose": "software_smoke_test_only",
    "human_speech": False, "has_historical_experiment_provenance": False,
    "claim_of_evidence_for_published_metrics": False,
}, indent=2), encoding="utf-8")
print(f"Created {len(samples)} electronic tone test fixtures in {OUT}")
