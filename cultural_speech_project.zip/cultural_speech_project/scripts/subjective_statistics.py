"""Analyze paired participant ratings and content-evaluator scores."""

import argparse
import csv
import json
import sys
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from cultural_speech.config import save_json
from cultural_speech.metrics import friedman_with_kendall_w, mean_sd_ci


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--dimension", default="overall_satisfaction")
    args = parser.parse_args()
    with open(args.input, newline="", encoding="utf-8") as handle:
        records = list(csv.DictReader(handle))
    if not records:
        raise ValueError("No participant ratings")
    rows = defaultdict(dict)
    for record in records:
        score = float(record[args.dimension])
        if not 1 <= score <= 5:
            raise ValueError("Ratings must use the 1 to 5 scale")
        key = record["participant_id"]
        system = record["system"]
        if system in rows[key]:
            raise ValueError("Repeated score for participant/system")
        rows[key][system] = score
    systems = sorted({name for ratings in rows.values() for name in ratings})
    if any(set(ratings) != set(systems) for ratings in rows.values()):
        raise ValueError("Missing systems for within-subject ratings")
    matrix = [[scores[system] for system in systems] for scores in rows.values()]
    summary = {"dimension": args.dimension, "systems": systems,
               "source_type": "participant_ratings",
               "paired_test": friedman_with_kendall_w(matrix),
               "by_system": {name: mean_sd_ci([scores[name] for scores in rows.values()])
                             for name in systems}}
    save_json(args.output, summary)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
