"""Measure single-utterance CPU inference and optional INT8 dynamic quantization."""

import argparse
import json
import os
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

import numpy as np
import psutil
import torch
from torch.utils.data import DataLoader

from cultural_speech.config import save_json
from cultural_speech.dataset import SpeechDataset, collate_speech, load_records
from cultural_speech.model import JointSpeechSemanticModel
from cultural_speech.vocab import CharacterVocabulary


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--int8", action="store_true")
    parser.add_argument("--allow-demo", action="store_true")
    parser.add_argument("--warmup", type=int, default=20)
    parser.add_argument("--count", type=int, default=100)
    args = parser.parse_args()
    checkpoint = torch.load(args.checkpoint, map_location="cpu", weights_only=False)
    cfg = checkpoint["config"]
    vocab = CharacterVocabulary(checkpoint["vocab_tokens"])
    model = JointSpeechSemanticModel(vocab.size, cfg["model"])
    model.load_state_dict(checkpoint["model_state"])
    model.eval()
    if args.int8:
        model = torch.ao.quantization.quantize_dynamic(model, {torch.nn.LSTM, torch.nn.Linear}, dtype=torch.qint8)
    origins = ("observed", "public_corpus", "synthetic_demo") if args.allow_demo else ("observed", "public_corpus")
    records = load_records(args.manifest, origins)
    loader = DataLoader(SpeechDataset(records, vocab, cfg["features"]), batch_size=1,
                        collate_fn=lambda rows: collate_speech(rows, vocab))
    batches = list(loader)
    if not batches:
        raise ValueError("No inference samples available")
    duration = [r["duration_seconds"] for r in records] if "duration_seconds" in records[0] else None
    if duration is None:
        import soundfile as sf
        duration = [sf.info(r["audio_path"]).duration for r in records]
    process = psutil.Process(os.getpid())
    with torch.no_grad():
        for i in range(args.warmup):
            model(batches[i % len(batches)])
        wall_start = time.perf_counter()
        times, ram_bytes = [], []
        for i in range(args.count):
            start = time.perf_counter()
            model(batches[i % len(batches)])
            times.append(time.perf_counter() - start)
            ram_bytes.append(process.memory_info().rss)
        wall_seconds = time.perf_counter() - wall_start
    mean_duration = float(np.mean([duration[i % len(duration)] for i in range(args.count)]))
    result = {"origin": "synthetic_demo" if args.allow_demo else "observed_or_public",
              "quantization": "dynamic_int8" if args.int8 else "fp32",
              "warmup": args.warmup, "evaluated": args.count,
              "mean_latency_ms": float(np.mean(times) * 1000),
              "p95_latency_ms": float(np.percentile(times, 95) * 1000),
              "real_time_factor": float(np.mean(times) / mean_duration),
              "throughput_utterances_per_second": args.count / wall_seconds,
              "peak_process_rss_mb": max(ram_bytes) / (1024 * 1024),
              "cpu_utilization_pct": None, "input_power_watts": None,
              "note": "External power-meter and processor-wide CPU readings require target hardware"}
    save_json(args.output, result)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
