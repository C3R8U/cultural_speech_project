"""Run inference on a held-out audio manifest and save sample-level outputs."""

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

import torch
from torch.utils.data import DataLoader

from cultural_speech.config import save_json, sha256_file
from cultural_speech.dataset import SpeechDataset, collate_speech, load_records
from cultural_speech.decode import decode_batch
from cultural_speech.metrics import error_rate, generation_metrics, intent_metrics
from cultural_speech.model import JointSpeechSemanticModel
from cultural_speech.training import to_device
from cultural_speech.vocab import CharacterVocabulary

INTENT_NAMES = ["cultural_inquiry", "emotional_expression", "creative_request"]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--test", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--allow-demo", action="store_true")
    parser.add_argument("--bertscore-model", default=None)
    parser.add_argument("--rerank-config", default=None)
    args = parser.parse_args()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    checkpoint = torch.load(args.checkpoint, map_location=device, weights_only=False)
    cfg = checkpoint["config"]
    vocab = CharacterVocabulary(checkpoint["vocab_tokens"])
    model = JointSpeechSemanticModel(vocab.size, cfg["model"]).to(device)
    model.load_state_dict(checkpoint["model_state"])
    model.eval()
    tuned = (json.loads(Path(args.rerank_config).read_text(encoding="utf-8"))
             if args.rerank_config else None)
    weight = tuned["selected_weight"] if tuned else cfg["model"].get("rerank_weight")
    if weight is None:
        raise ValueError("CTC semantic re-ranking weight must be selected on validation data")
    origins = ("observed", "public_corpus", "synthetic_demo") if args.allow_demo else ("observed", "public_corpus")
    records = load_records(args.test, allowed_origins=origins)
    dataset = SpeechDataset(records, vocab, cfg["features"])
    loader = DataLoader(dataset, batch_size=1, shuffle=False,
                        collate_fn=lambda items: collate_speech(items, vocab))
    predictions = []
    with torch.no_grad():
        for batch in loader:
            batch = to_device(batch, device)
            result = model(batch)
            transcript = decode_batch(model, result, batch["feature_lengths"], vocab,
                                      beam_size=cfg["model"]["beam_size"],
                                      rerank_count=cfg["model"]["rerank_candidates"],
                                      rerank_weight=weight)[0]
            predicted_intent = int(result["intent_logits"].argmax(dim=-1).item())
            generated_text = model.greedy_generate(
                result["context"], vocab, cfg["model"]["generation_max_story_tokens"]
            )[0]
            actual_record = batch["records"][0]
            predictions.append({
                "sample_id": actual_record["sample_id"], "dataset": actual_record.get("dataset"),
                "origin": actual_record["origin"], "split": actual_record.get("split"),
                "scenario": actual_record.get("scenario"),
                "reference_text": actual_record["text"],
                "prediction_text": transcript["transcription"],
                "reference_intent": actual_record.get("intent"),
                "predicted_intent": INTENT_NAMES[predicted_intent],
                "generation_reference": actual_record.get("target_text", ""),
                "generation_output": generated_text,
                "ctc_log_score": transcript["ctc_log_score"],
                "semantic_similarity": transcript["semantic_similarity"],
            })
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    with (output / "predictions.jsonl").open("w", encoding="utf-8") as handle:
        for record in predictions:
            handle.write(json.dumps(record, ensure_ascii=False) + "\n")
    pairs = [(p["reference_text"], p["prediction_text"]) for p in predictions]
    summary = {
        "origin": "synthetic_demo" if args.allow_demo and any(p["origin"] == "synthetic_demo" for p in predictions) else "observed_or_public",
        "count": len(predictions),
        "manifest_sha256": sha256_file(args.test),
        "cer": error_rate(pairs, "character"),
        "wer": error_rate(pairs, cfg["metrics"]["chinese_word_segmentation"]),
        "wer_tokenization": cfg["metrics"]["chinese_word_segmentation"],
        "rerank_weight": weight,
    }
    valid = [p for p in predictions if p["reference_intent"] in INTENT_NAMES]
    if valid:
        summary["intent"] = intent_metrics(
            [INTENT_NAMES.index(p["reference_intent"]) for p in valid],
            [INTENT_NAMES.index(p["predicted_intent"]) for p in valid],
        )
    creative = [p for p in predictions if p["generation_reference"]]
    if creative:
        summary["generation"] = generation_metrics(
            [p["generation_reference"] for p in creative],
            [p["generation_output"] for p in creative],
            bertscore_model=args.bertscore_model,
        )
    save_json(output / "evaluation.json", summary)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
