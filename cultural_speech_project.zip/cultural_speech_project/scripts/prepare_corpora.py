"""Convert recorded speech and text collections into stable experiment manifests."""

import argparse
import csv
import hashlib
import json
import random
from collections import Counter, defaultdict
from pathlib import Path

import soundfile as sf


def write_jsonl(path, records):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as handle:
        for record in records:
            handle.write(json.dumps(record, ensure_ascii=False) + "\n")


def audio_duration(path):
    info = sf.info(str(path))
    return info.frames / info.samplerate


def normalize_record(sample_id, audio_path, speaker_id, text, dataset, split,
                     origin="observed", intent=None, scenario=None, target_text=""):
    path = Path(audio_path).expanduser().resolve()
    if not path.is_file():
        raise FileNotFoundError(f"Required audio file missing: {path}")
    if not text or not str(text).strip():
        raise ValueError(f"No transcription for {sample_id}")
    return {
        "sample_id": str(sample_id), "audio_path": str(path),
        "speaker_id": str(speaker_id), "text": str(text).strip(),
        "dataset": dataset, "split": split, "origin": origin,
        "intent": intent, "scenario": scenario, "target_text": target_text,
        "duration_seconds": round(audio_duration(path), 5),
    }


def prepare_aishell(args):
    """OpenSLR extracts train/dev/test WAV folders and transcript text files."""
    root = Path(args.root)
    transcript_files = list(root.rglob("*.trans.txt"))
    if not transcript_files:
        raise FileNotFoundError("Expected AISHELL transcription *.trans.txt files")
    transcripts = {}
    for path in transcript_files:
        for line in path.read_text(encoding="utf-8").splitlines():
            parts = line.split(maxsplit=1)
            if len(parts) == 2:
                transcripts[parts[0]] = parts[1].replace(" ", "")
    by_split = defaultdict(list)
    for wav in root.rglob("*.wav"):
        split = next((part for part in wav.parts if part in ("train", "dev", "test")), None)
        if not split or wav.stem not in transcripts:
            continue
        by_split[split].append(normalize_record(
            wav.stem, wav, wav.parent.name, transcripts[wav.stem],
            "AISHELL-1", split, origin="public_corpus"
        ))
    if not by_split:
        raise ValueError("No aligned AISHELL WAV/transcription pairs found")
    for split, records in by_split.items():
        write_jsonl(Path(args.output) / f"aishell_{split}.jsonl", records)
    print({key: len(value) for key, value in by_split.items()})


def prepare_common_voice(args):
    """Read locally downloaded validated TSV and segment by duration."""
    base = Path(args.root)
    source = base / args.tsv
    if not source.exists():
        raise FileNotFoundError(source)
    values = []
    with source.open(encoding="utf-8") as handle:
        for row in csv.DictReader(handle, delimiter="\t"):
            name = row.get("path", "")
            transcript = row.get("sentence", "")
            if not name or not transcript:
                continue
            path = base / "clips" / name
            if not path.is_file():
                continue
            duration = audio_duration(path)
            if 1.5 <= duration <= 12.0:
                values.append((row, path, duration))
    if not values:
        raise ValueError("No usable Common Voice clips found")
    rng = random.Random(args.seed)
    rng.shuffle(values)
    goal_hours = {"train": 36.0, "dev": 4.0, "test": 4.0}
    totals = dict.fromkeys(goal_hours, 0.0)
    records = defaultdict(list)
    speaker_assignments = {}
    for row, path, duration in values:
        speaker = row.get("client_id") or f"unknown_{path.stem}"
        selected = speaker_assignments.get(speaker)
        if selected is None:
            selected = next((s for s in goal_hours if totals[s] + duration / 3600 <= goal_hours[s]), None)
            if selected is None:
                continue
            speaker_assignments[speaker] = selected
        if totals[selected] + duration / 3600 > goal_hours[selected]:
            continue
        records[selected].append(normalize_record(
            path.stem, path, speaker, row["sentence"],
            "Common Voice Chinese v16", selected, origin="public_corpus"
        ))
        totals[selected] += duration / 3600
    for split, items in records.items():
        write_jsonl(Path(args.output) / f"common_voice_{split}.jsonl", items)
    print({"hours": totals, "count": {k: len(v) for k, v in records.items()},
           "note": "Exact 36/4/4-hour source selection requires the archived sample IDs"})


def prepare_cultural(args):
    """A metadata CSV is valid only when its referenced audio files are present."""
    table = Path(args.csv)
    rows = list(csv.DictReader(table.open(encoding="utf-8-sig", newline="")))
    by_split = defaultdict(list)
    seen_speakers = defaultdict(set)
    seen_samples = set()
    for row in rows:
        sample_id = row["sample_id"]
        if sample_id in seen_samples:
            raise ValueError(f"Duplicate sample ID: {sample_id}")
        seen_samples.add(sample_id)
        split = row.get("split", "test" if args.dataset == "Field-Culture Test" else "train")
        path = Path(row["audio_path"])
        if not path.is_absolute():
            path = (Path(args.audio_root) / path).resolve()
        origin = row.get("origin", "observed")
        if origin != "observed":
            raise ValueError("The cultural corpus importer accepts recorded observations only")
        record = normalize_record(
            sample_id, path, row["speaker_id"], row["text"],
            args.dataset, split, origin=origin,
            intent=row.get("intent"), scenario=row.get("scenario"),
            target_text=row.get("target_text", ""),
        )
        by_split[split].append(record)
        seen_speakers[split].add(record["speaker_id"])
    if args.dataset == "Field-Culture Test" and any(s != "test" for s in by_split):
        raise ValueError("Field-Culture Test must be held out for evaluation")
    if args.dataset == "CSSP":
        splits = list(seen_speakers)
        for i, first in enumerate(splits):
            for second in splits[i+1:]:
                if seen_speakers[first] & seen_speakers[second]:
                    raise ValueError(f"Speaker overlap: {first} and {second}")
    prefix = "cssp" if args.dataset == "CSSP" else "field_culture"
    for split, items in by_split.items():
        write_jsonl(Path(args.output) / f"{prefix}_{split}.jsonl", items)
    print({key: len(value) for key, value in by_split.items()})


def prepare_text(args):
    """Keep each selected text sequence identifiable by its source file hash."""
    root = Path(args.root)
    paths = sorted(p for p in root.rglob("*") if p.is_file() and p.suffix.lower() in (".txt", ".json"))
    collected = []
    for path in paths:
        if path.suffix.lower() == ".txt":
            content = path.read_text(encoding="utf-8", errors="ignore")
            texts = [content.strip()] if content.strip() else []
        else:
            try:
                values = json.loads(path.read_text(encoding="utf-8"))
            except (ValueError, UnicodeDecodeError):
                continue
            if isinstance(values, dict):
                values = [values]
            texts = []
            if isinstance(values, list):
                for item in values:
                    if not isinstance(item, dict):
                        continue
                    if args.kind == "poetry":
                        paras = item.get("paragraphs", item.get("content", []))
                        value = "".join(paras) if isinstance(paras, list) else str(paras)
                    else:
                        value = str(item.get("text", item.get("content", "")))
                    if value.strip():
                        texts.append(value.strip())
        for offset, text in enumerate(texts):
            collected.append({"sample_id": f"{path.name}:{offset}", "text": text,
                              "source_path": str(path.resolve()), "origin": "public_corpus",
                              "dataset": args.kind})
    random.Random(args.seed).shuffle(collected)
    if args.limit:
        collected = collected[:args.limit]
    n = len(collected)
    targets = [int(n * 0.7777778), int(n * 0.1111111)] if args.kind == "thucnews" else [int(n * 5 / 6), int(n / 12)]
    split_at = [targets[0], targets[0] + targets[1]]
    result = {"train": collected[:split_at[0]], "dev": collected[split_at[0]:split_at[1]],
              "test": collected[split_at[1]:]}
    for split, rows in result.items():
        write_jsonl(Path(args.output) / f"{args.kind}_{split}.jsonl", rows)
    print({key: len(value) for key, value in result.items()})


def main():
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="kind", required=True)
    for name in ("aishell", "common_voice", "cultural", "thucnews", "poetry"):
        p = sub.add_parser(name)
        p.add_argument("--output", required=True)
        if name == "cultural":
            p.add_argument("--csv", required=True)
            p.add_argument("--audio-root", required=True)
            p.add_argument("--dataset", required=True, choices=["CSSP", "Field-Culture Test"])
        else:
            p.add_argument("--root", required=True)
        if name == "common_voice":
            p.add_argument("--tsv", default="validated.tsv")
        if name in ("thucnews", "poetry"):
            p.add_argument("--limit", type=int, default=90000 if name == "thucnews" else 60000)
        p.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()
    if args.kind == "aishell":
        prepare_aishell(args)
    elif args.kind == "common_voice":
        prepare_common_voice(args)
    elif args.kind == "cultural":
        prepare_cultural(args)
    else:
        prepare_text(args)


if __name__ == "__main__":
    main()
