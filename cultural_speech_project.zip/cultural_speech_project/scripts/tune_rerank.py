"""Select the CTC semantic re-ranking coefficient from validation audio."""

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

import torch
from torch.utils.data import DataLoader

from cultural_speech.config import save_json, sha256_file
from cultural_speech.dataset import SpeechDataset, collate_speech, load_records
from cultural_speech.decode import decode_batch
from cultural_speech.metrics import error_rate
from cultural_speech.model import JointSpeechSemanticModel
from cultural_speech.training import to_device
from cultural_speech.vocab import CharacterVocabulary


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--validation", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--weights", nargs="+", type=float,
                        default=[0.0, 0.10, 0.25, 0.50, 1.0])
    parser.add_argument("--allow-demo", action="store_true")
    args = parser.parse_args()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    checkpoint = torch.load(args.checkpoint, map_location=device, weights_only=False)
    cfg = checkpoint["config"]
    vocab = CharacterVocabulary(checkpoint["vocab_tokens"])
    model = JointSpeechSemanticModel(vocab.size, cfg["model"]).to(device)
    model.load_state_dict(checkpoint["model_state"])
    model.eval()
    origins = ("observed", "public_corpus", "synthetic_demo") if args.allow_demo else ("observed", "public_corpus")
    rows = load_records(args.validation, allowed_origins=origins)
    loader = DataLoader(SpeechDataset(rows, vocab, cfg["features"]), batch_size=1,
                        collate_fn=lambda items: collate_speech(items, vocab))
    scores = {}
    with torch.no_grad():
        for weight in args.weights:
            pairs = []
            for batch in loader:
                batch = to_device(batch, device)
                outputs = model(batch)
                prediction = decode_batch(
                    model, outputs, batch["feature_lengths"], vocab,
                    cfg["model"]["beam_size"], cfg["model"]["rerank_candidates"], weight
                )[0]["transcription"]
                pairs.append((batch["records"][0]["text"], prediction))
            scores[str(weight)] = error_rate(pairs, "character")
    best = min(args.weights, key=lambda weight: (scores[str(weight)], weight))
    save_json(args.output, {"selected_weight": best, "validation_cer_by_weight": scores,
                            "selection_metric": "character_error_rate",
                            "validation_manifest_sha256": sha256_file(args.validation),
                            "origin": "synthetic_demo" if args.allow_demo else "observed_or_public"})
    print(json.dumps({"selected_weight": best, "scores": scores}, indent=2))


if __name__ == "__main__":
    main()
