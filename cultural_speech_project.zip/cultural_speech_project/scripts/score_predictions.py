"""Calculate metrics from saved sample-level outputs without running the model."""

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from cultural_speech.config import save_json
from cultural_speech.metrics import error_rate, generation_metrics, intent_metrics
from cultural_speech.dataset import INTENTS


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--word-mode", choices=["jieba", "character"], default="jieba")
    args = parser.parse_args()
    with open(args.input, encoding="utf-8") as handle:
        rows = [json.loads(line) for line in handle if line.strip()]
    if not rows:
        raise ValueError("Prediction file is empty")
    pairs = [(r["reference_text"], r["prediction_text"]) for r in rows]
    summary = {"count": len(rows), "origin_values": sorted(set(r["origin"] for r in rows)),
               "cer": error_rate(pairs), "wer": error_rate(pairs, args.word_mode),
               "word_mode": args.word_mode}
    classified = [r for r in rows if r.get("reference_intent") in INTENTS]
    if classified:
        summary["intent"] = intent_metrics(
            [INTENTS[r["reference_intent"]] for r in classified],
            [INTENTS[r["predicted_intent"]] for r in classified],
        )
    creative = [r for r in rows if r.get("generation_reference")]
    if creative:
        summary["generation"] = generation_metrics(
            [r["generation_reference"] for r in creative],
            [r["generation_output"] for r in creative],
        )
    save_json(args.output, summary)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
