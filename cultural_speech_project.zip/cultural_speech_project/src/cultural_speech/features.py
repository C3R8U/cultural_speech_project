"""Speech waveform loading and 39-dimensional dynamic MFCC features."""

from functools import lru_cache

import librosa
import numpy as np
import soundfile as sf


def extract_mfcc(path, cfg):
    """Concatenate static coefficients with their first and second differences."""
    wave, sample_rate = sf.read(path, dtype="float32", always_2d=False)
    if wave.ndim == 2:
        wave = wave.mean(axis=1)
    desired = int(cfg["sample_rate"])
    if sample_rate != desired:
        wave = librosa.resample(wave, orig_sr=sample_rate, target_sr=desired)
    window = round(cfg["window_ms"] * desired / 1000)
    hop = round(cfg["hop_ms"] * desired / 1000)
    mfcc = librosa.feature.mfcc(
        y=wave, sr=desired, n_mfcc=cfg["n_mfcc"],
        n_fft=cfg.get("n_fft", window), hop_length=hop,
        win_length=window, n_mels=cfg.get("n_mels", 40),
        center=False,
    )
    if mfcc.shape[1] < 9:
        mfcc = np.pad(mfcc, ((0, 0), (0, 9 - mfcc.shape[1])), mode="edge")
    delta = librosa.feature.delta(mfcc, order=1)
    delta2 = librosa.feature.delta(mfcc, order=2)
    features = np.concatenate([mfcc, delta, delta2], axis=0).T
    if features.shape[1] != 39:
        raise ValueError("Expected 39 acoustic features per frame")
    return features.astype(np.float32)
