"""Character-level vocabularies for CTC and generative language modeling."""

import json
from collections import Counter


class CharacterVocabulary:
    special = ["<blank>", "<pad>", "<bos>", "<eos>", "<unk>"]

    def __init__(self, tokens):
        self.tokens = list(tokens)
        self.to_id = {token: index for index, token in enumerate(self.tokens)}
        for token in self.special:
            if token not in self.to_id:
                raise ValueError(f"Missing special token: {token}")

    @classmethod
    def from_texts(cls, texts, minimum_frequency=1):
        counts = Counter(ch for text in texts for ch in text)
        chars = sorted(char for char, count in counts.items()
                       if count >= minimum_frequency and char not in cls.special)
        return cls(cls.special + chars)

    @property
    def size(self):
        return len(self.tokens)

    def encode(self, text):
        return [self.to_id.get(character, self.to_id["<unk>"]) for character in text]

    def decode(self, ids, skip_special=True):
        return "".join(self.tokens[int(i)] for i in ids
                       if not skip_special or self.tokens[int(i)] not in self.special)

    def save(self, path):
        with open(path, "w", encoding="utf-8") as handle:
            json.dump(self.tokens, handle, ensure_ascii=False)

    @classmethod
    def load(cls, path):
        with open(path, encoding="utf-8") as handle:
            return cls(json.load(handle))
