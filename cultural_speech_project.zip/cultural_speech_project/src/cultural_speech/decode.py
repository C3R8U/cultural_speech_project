"""CTC prefix search with semantic candidate ranking."""

import math

import torch
from torch.nn import functional as F


def log_add(*values):
    values = [v for v in values if v != -math.inf]
    if not values:
        return -math.inf
    high = max(values)
    return high + math.log(sum(math.exp(value - high) for value in values))


def prefix_beam_search(log_probabilities, blank_id=0, width=10):
    """Track prefixes ending in blank and non-blank separately."""
    prefixes = {(): (0.0, -math.inf)}
    for frame in log_probabilities:
        new_prefixes = {}
        # Pruning the character expansion reduces work without altering CTC rules.
        candidates = torch.topk(frame, k=min(width + 2, frame.numel()))
        labels = candidates.indices.tolist()
        scores = candidates.values.tolist()
        if blank_id not in labels:
            labels.append(blank_id)
            scores.append(float(frame[blank_id]))
        for prefix, (p_blank, p_nonblank) in prefixes.items():
            for char, logp in zip(labels, scores):
                if char == blank_id:
                    old_b, old_nb = new_prefixes.get(prefix, (-math.inf, -math.inf))
                    new_prefixes[prefix] = (log_add(old_b, p_blank + logp, p_nonblank + logp), old_nb)
                elif prefix and char == prefix[-1]:
                    old_b, old_nb = new_prefixes.get(prefix, (-math.inf, -math.inf))
                    new_prefixes[prefix] = (old_b, log_add(old_nb, p_nonblank + logp))
                    extended = prefix + (char,)
                    old_b, old_nb = new_prefixes.get(extended, (-math.inf, -math.inf))
                    new_prefixes[extended] = (old_b, log_add(old_nb, p_blank + logp))
                else:
                    extended = prefix + (char,)
                    old_b, old_nb = new_prefixes.get(extended, (-math.inf, -math.inf))
                    new_prefixes[extended] = (
                        old_b, log_add(old_nb, p_blank + logp, p_nonblank + logp)
                    )
        prefixes = dict(sorted(
            new_prefixes.items(),
            key=lambda item: log_add(*item[1]), reverse=True,
        )[:width])
    return [(list(prefix), log_add(*state)) for prefix, state in sorted(
        prefixes.items(), key=lambda item: log_add(*item[1]), reverse=True
    )]


@torch.no_grad()
def decode_batch(model, outputs, lengths, vocab, beam_size=10, rerank_count=5, rerank_weight=0.35):
    """Only CTC beam candidates may be returned by semantic re-ranking."""
    results = []
    for row, length in enumerate(lengths.tolist()):
        candidates = prefix_beam_search(outputs["log_probs"][row, :length].cpu(),
                                        blank_id=0, width=beam_size)
        reference = outputs["context"][row:row+1]
        ranked = []
        for index, (ids, acoustic_score) in enumerate(candidates):
            semantic_score = 0.0
            if index < rerank_count:
                valid_ids = [idx for idx in ids if idx not in range(5)]
                semantic = model.encode_candidate(valid_ids, reference.device)
                if semantic is not None:
                    semantic_score = float(F.cosine_similarity(reference, semantic).item())
                total_score = acoustic_score + rerank_weight * semantic_score
                ranked.append((total_score, ids, acoustic_score, semantic_score))
        if not ranked:
            ranked = [(0.0, [], 0.0, 0.0)]
        score, ids, acoustic, semantic = max(ranked, key=lambda item: item[0])
        results.append({
            "transcription": vocab.decode(ids),
            "ctc_log_score": acoustic,
            "semantic_similarity": semantic,
            "combined_score": score,
        })
    return results
