"""Manifest-backed datasets keep audio and annotations aligned by sample ID."""

import json
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import Dataset

from .features import extract_mfcc

INTENTS = {"cultural_inquiry": 0, "emotional_expression": 1, "creative_request": 2}


def load_records(path, allowed_origins=("observed", "public_corpus")):
    records = []
    with open(path, encoding="utf-8") as handle:
        for line_no, line in enumerate(handle, 1):
            if not line.strip():
                continue
            record = json.loads(line)
            if record.get("origin") not in allowed_origins:
                raise ValueError(
                    f"Unsupported data origin at line {line_no}: {record.get('origin')}. "
                    "An explicitly permitted demo origin is required for generated fixtures."
                )
            if not record.get("sample_id") or not record.get("text"):
                raise ValueError(f"Missing sample_id/text on line {line_no}")
            audio_path = Path(record["audio_path"]).expanduser()
            if not audio_path.is_absolute():
                audio_path = (Path(path).resolve().parent / audio_path).resolve()
            if not audio_path.exists():
                raise FileNotFoundError(str(audio_path))
            record["audio_path"] = str(audio_path)
            records.append(record)
    ids = [r["sample_id"] for r in records]
    if len(ids) != len(set(ids)):
        raise ValueError("Duplicate sample IDs")
    return records


class SpeechDataset(Dataset):
    def __init__(self, records, vocabulary, feature_cfg):
        self.records = records
        self.vocab = vocabulary
        self.feature_cfg = feature_cfg

    def __len__(self):
        return len(self.records)

    def __getitem__(self, index):
        record = self.records[index]
        feats = extract_mfcc(record["audio_path"], self.feature_cfg)
        intent = INTENTS.get(record.get("intent"), -1)
        target_text = record.get("target_text", "")
        ids = self.vocab.encode(record["text"])
        if not ids:
            raise ValueError(f"Empty transcription for {record['sample_id']}")
        target_ids = self.vocab.encode(target_text)
        return {
            "sample_id": record["sample_id"],
            "features": torch.from_numpy(feats),
            "text_ids": torch.tensor(ids, dtype=torch.long),
            "intent": intent,
            "target_ids": torch.tensor(target_ids, dtype=torch.long),
            "record": record,
        }


def collate_speech(items, vocab):
    batch_size = len(items)
    max_time = max(item["features"].size(0) for item in items)
    feats = torch.zeros(batch_size, max_time, 39)
    lens = torch.tensor([item["features"].size(0) for item in items], dtype=torch.long)
    ctc_targets = torch.cat([item["text_ids"] for item in items])
    ctc_target_lens = torch.tensor([item["text_ids"].numel() for item in items])
    bos, eos, pad = (vocab.to_id[key] for key in ("<bos>", "<eos>", "<pad>"))
    max_target_len = max(item["target_ids"].numel() + 1 for item in items)
    decoder_input = torch.full((batch_size, max_target_len), pad, dtype=torch.long)
    decoder_target = torch.full_like(decoder_input, pad)
    for idx, item in enumerate(items):
        length = lens[idx]
        feats[idx, :length] = item["features"]
        seq = item["target_ids"].tolist()
        if seq:
            decoder_input[idx, :len(seq) + 1] = torch.tensor([bos] + seq)
            decoder_target[idx, :len(seq) + 1] = torch.tensor(seq + [eos])
    return {
        "features": feats,
        "feature_lengths": lens,
        "ctc_targets": ctc_targets,
        "ctc_target_lengths": ctc_target_lens,
        "intent": torch.tensor([item["intent"] for item in items]),
        "decoder_input": decoder_input,
        "decoder_target": decoder_target,
        "records": [item["record"] for item in items],
    }
