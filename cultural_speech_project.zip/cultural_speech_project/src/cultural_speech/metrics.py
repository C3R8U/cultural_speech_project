"""Evaluation metrics from sample-level predictions and reference labels."""

import math
import statistics
from collections import Counter

import numpy as np
from scipy.stats import friedmanchisquare, t as t_distribution
from sklearn.metrics import (accuracy_score, confusion_matrix,
                             precision_recall_fscore_support)


def edit_distance(reference, hypothesis):
    """Dynamic programming works for both token sequences and character strings."""
    previous = list(range(len(hypothesis) + 1))
    for i, left in enumerate(reference, 1):
        current = [i]
        for j, right in enumerate(hypothesis, 1):
            current.append(min(previous[j] + 1, current[-1] + 1,
                               previous[j - 1] + (left != right)))
        previous = current
    return previous[-1]


def tokenize_chinese(text, mode="jieba"):
    clean = "".join(text.strip().split())
    if mode == "character":
        return list(clean)
    if mode == "jieba":
        try:
            import jieba
        except ImportError as exc:
            raise RuntimeError("Install jieba to use word segmentation") from exc
        return list(jieba.cut(clean, HMM=False))
    raise ValueError(f"Unknown segmentation mode: {mode}")


def error_rate(pairs, mode="character"):
    numerator = denominator = 0
    for reference, prediction in pairs:
        if mode == "character":
            expected, actual = list(reference), list(prediction)
        else:
            expected = tokenize_chinese(reference, mode)
            actual = tokenize_chinese(prediction, mode)
        numerator += edit_distance(expected, actual)
        denominator += len(expected)
    return float(numerator / denominator) if denominator else None


def intent_metrics(actual, predicted):
    labels = [0, 1, 2]
    precision, recall, f1, support = precision_recall_fscore_support(
        actual, predicted, labels=labels, zero_division=0
    )
    macro_precision, macro_recall, macro_f1, _ = precision_recall_fscore_support(
        actual, predicted, average="macro", labels=labels, zero_division=0
    )
    return {
        "accuracy": float(accuracy_score(actual, predicted)),
        "macro_precision": float(macro_precision),
        "macro_recall": float(macro_recall),
        "macro_f1": float(macro_f1),
        "per_class": [{"label": label, "precision": float(precision[i]),
                       "recall": float(recall[i]), "f1": float(f1[i]),
                       "support": int(support[i])} for i, label in enumerate(labels)],
        "confusion_matrix": confusion_matrix(actual, predicted, labels=labels).tolist(),
    }


def corpus_bleu2(references, hypotheses):
    """Character-level corpus BLEU with clipped one- and two-gram precision."""
    matches = [0, 0]
    totals = [0, 0]
    ref_len = hyp_len = 0
    for reference, hypothesis in zip(references, hypotheses):
        ref, hyp = list(reference), list(hypothesis)
        ref_len += len(ref)
        hyp_len += len(hyp)
        for size in [1, 2]:
            reference_counts = Counter(tuple(ref[i:i+size]) for i in range(len(ref) - size + 1))
            hypothesis_counts = Counter(tuple(hyp[i:i+size]) for i in range(len(hyp) - size + 1))
            matches[size-1] += sum(min(count, reference_counts[gram]) for gram, count in hypothesis_counts.items())
            totals[size-1] += sum(hypothesis_counts.values())
    if not hyp_len:
        return 0.0
    precision = [matches[i] / totals[i] if totals[i] else 0 for i in range(2)]
    if min(precision) <= 0:
        return 0.0
    brevity = min(1.0, math.exp(1 - ref_len / hyp_len))
    return 100.0 * brevity * math.sqrt(precision[0] * precision[1])


def rouge_l_f1(references, hypotheses):
    """Sentence-average longest-common-subsequence F1 over Chinese characters."""
    scores = []
    for reference, prediction in zip(references, hypotheses):
        left, right = list(reference), list(prediction)
        if not left or not right:
            scores.append(0.0)
            continue
        # Keep the overlap score focused on the longest ordered common sequence.
        previous = [0] * (len(right) + 1)
        for a in left:
            current = [0]
            for j, b in enumerate(right, 1):
                current.append(previous[j - 1] + 1 if a == b else max(previous[j], current[-1]))
            previous = current
        lcs = previous[-1]
        scores.append(2.0 * lcs / (len(left) + len(right)))
    return 100.0 * float(np.mean(scores)) if scores else None


def generation_metrics(references, hypotheses, bertscore_model=None):
    if len(references) != len(hypotheses):
        raise ValueError("Reference and hypothesis counts differ")
    result = {
        "bleu2_character_corpus": corpus_bleu2(references, hypotheses),
        "rouge_l_character_sentence_f1": rouge_l_f1(references, hypotheses),
    }
    if bertscore_model is not None:
        from bert_score import score
        _, _, f1 = score(hypotheses, references, lang="zh", model_type=bertscore_model,
                         verbose=False, rescale_with_baseline=False)
        result["bertscore_f1"] = float(f1.mean())
        result["bertscore_model"] = bertscore_model
    else:
        result["bertscore_f1"] = None
    return result


def mean_sd_ci(values, confidence=0.95):
    if not values:
        return {"mean": None, "sd": None, "ci": None, "n": 0}
    mean = float(statistics.mean(values))
    if len(values) < 2:
        return {"mean": mean, "sd": None, "ci": None, "n": len(values)}
    sd = float(statistics.stdev(values))
    radius = float(t_distribution.ppf((1 + confidence) / 2, df=len(values) - 1)) * sd / math.sqrt(len(values))
    return {"mean": mean, "sd": sd, "ci": [mean - radius, mean + radius], "n": len(values)}


def friedman_with_kendall_w(matrix):
    """Rows are participants; columns are systems measured on the same tasks."""
    observed = np.asarray(matrix, dtype=float)
    if observed.ndim != 2 or observed.shape[1] < 3:
        raise ValueError("Friedman analysis needs at least three paired systems")
    statistic, p_value = friedmanchisquare(*(observed[:, i] for i in range(observed.shape[1])))
    n, k = observed.shape
    return {"friedman_chi2": float(statistic), "p_value": float(p_value),
            "kendalls_w": float(statistic / (n * (k - 1))),
            "participants": n, "systems": k}


def paired_bootstrap_wer(reference, predictions_a, predictions_b, repetitions=10000, seed=42):
    """Resample matched utterances to compare two recognizers on the same test set."""
    if not (len(reference) == len(predictions_a) == len(predictions_b)):
        raise ValueError("The same utterances must be scored for both systems")
    rng = np.random.default_rng(seed)
    differences = []
    n = len(reference)
    for _ in range(repetitions):
        indices = rng.integers(0, n, size=n)
        pa = [(reference[i], predictions_a[i]) for i in indices]
        pb = [(reference[i], predictions_b[i]) for i in indices]
        differences.append(error_rate(pa) - error_rate(pb))
    return {"difference_a_minus_b": float(np.mean(differences)),
            "ci95": [float(np.quantile(differences, 0.025)), float(np.quantile(differences, 0.975))],
            "draws": repetitions}
