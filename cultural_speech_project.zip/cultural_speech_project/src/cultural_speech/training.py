"""Batch optimization, checkpoint handling, and per-epoch measurements."""

import time
from pathlib import Path

import torch
from torch.utils.data import DataLoader

from .config import append_jsonl, save_json
from .dataset import collate_speech


def to_device(batch, device):
    return {name: tensor.to(device) if isinstance(tensor, torch.Tensor) else tensor
            for name, tensor in batch.items()}


def run_epoch(model, loader, optimizer, cfg, device):
    training = optimizer is not None
    model.train(training)
    totals = {"loss": 0.0, "ctc": 0.0, "intent": 0.0, "generation": 0.0}
    observed = {"ctc": 0, "intent": 0, "generation": 0}
    count = 0
    for batch in loader:
        batch = to_device(batch, device)
        with torch.set_grad_enabled(training):
            result = model(batch, cfg["model"]["loss_weights"])
            loss = result["loss"]
            if training:
                optimizer.zero_grad(set_to_none=True)
                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), cfg["optimization"]["gradient_clip_norm"])
                optimizer.step()
        count += 1
        totals["loss"] += float(loss.detach())
        for key, value in result["losses"].items():
            totals[key] += float(value.detach())
            observed[key] += 1
    return {key: round(value / (count if key == "loss" else max(1, observed[key])), 6)
            for key, value in totals.items()} | {"batches": count}


def train_model(model, train_dataset, dev_dataset, vocab, cfg, run_dir, seed, source_metadata):
    run_dir = Path(run_dir)
    run_dir.mkdir(parents=True, exist_ok=True)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.to(device)
    opt = torch.optim.Adam(model.parameters(), lr=cfg["optimization"]["learning_rate"],
                           weight_decay=cfg["optimization"].get("weight_decay", 0.0))
    train_loader = DataLoader(train_dataset, batch_size=cfg["optimization"]["batch_size"],
                              shuffle=True, num_workers=cfg["optimization"].get("num_workers", 0),
                              collate_fn=lambda items: collate_speech(items, vocab))
    dev_loader = DataLoader(dev_dataset, batch_size=cfg["optimization"]["batch_size"],
                            shuffle=False, num_workers=cfg["optimization"].get("num_workers", 0),
                            collate_fn=lambda items: collate_speech(items, vocab))
    best_loss = float("inf")
    stale = 0
    history = []
    for epoch in range(1, cfg["optimization"]["max_epochs"] + 1):
        start = time.perf_counter()
        train_metrics = run_epoch(model, train_loader, opt, cfg, device)
        dev_metrics = run_epoch(model, dev_loader, None, cfg, device)
        item = {"epoch": epoch, "seed": seed, "train": train_metrics,
                "validation": dev_metrics, "seconds": time.perf_counter() - start,
                "origin": source_metadata["origin"]}
        append_jsonl(run_dir / "training.jsonl", item)
        history.append(item)
        if dev_metrics["loss"] < best_loss:
            best_loss = dev_metrics["loss"]
            stale = 0
            torch.save({"model_state": model.state_dict(), "epoch": epoch,
                        "seed": seed, "config": cfg, "vocab_tokens": vocab.tokens,
                        "source_metadata": source_metadata}, run_dir / "best.pt")
        else:
            stale += 1
            if stale >= cfg["optimization"]["early_stop_patience"]:
                break
    save_json(run_dir / "run_summary.json", {
        "seed": seed, "origin": source_metadata["origin"],
        "best_validation_loss": best_loss, "epochs": len(history),
        "checkpoint": str(run_dir / "best.pt"),
        "metric_scope": "loss_only; sample-level metrics require held-out evaluation",
    })
    return history
