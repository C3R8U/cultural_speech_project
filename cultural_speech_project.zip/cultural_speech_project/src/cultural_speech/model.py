"""Joint CTC acoustic encoder, blank-aware semantic interface, and LSTM decoder."""

import torch
from torch import nn
from torch.nn import functional as F


class BlankAwareBridge(nn.Module):
    """Only non-blank characters contribute semantics at each acoustic frame."""

    def __init__(self, vocab_size, embedding_dim, blank_id=0):
        super().__init__()
        self.blank_id = blank_id
        self.embedding = nn.Embedding(vocab_size, embedding_dim)

    def forward(self, log_probabilities):
        probabilities = log_probabilities.exp()
        nonblank = 1.0 - probabilities[..., self.blank_id]
        # Conditional character posteriors are normalized before semantic mixing.
        weights = probabilities.clone()
        weights[..., self.blank_id] = 0.0
        weights = weights / nonblank.clamp_min(1e-7).unsqueeze(-1)
        semantic_vector = weights @ self.embedding.weight
        return semantic_vector * nonblank.unsqueeze(-1), nonblank


class JointSpeechSemanticModel(nn.Module):
    """The three training heads share one differentiable acoustic representation."""

    def __init__(self, vocab_size, config):
        super().__init__()
        self.config = config
        self.blank_id = int(config.get("ctc_blank_id", 0))
        hidden_acoustic = int(config["acoustic_hidden_per_direction"])
        acoustic_layers = int(config["acoustic_layers"])
        semantic_hidden = int(config["semantic_hidden"])
        embedding_dim = int(config["embedding_dim"])
        dropout = float(config.get("dropout", 0.30))
        self.encoder = nn.LSTM(
            39, hidden_acoustic, num_layers=acoustic_layers,
            bidirectional=True, batch_first=True,
            dropout=dropout if acoustic_layers > 1 else 0.0,
        )
        self.ctc_head = nn.Linear(hidden_acoustic * 2, vocab_size)
        self.bridge = BlankAwareBridge(vocab_size, embedding_dim, self.blank_id)
        self.semantic = nn.LSTM(
            embedding_dim, semantic_hidden, num_layers=config["semantic_layers"],
            batch_first=True, dropout=dropout if config["semantic_layers"] > 1 else 0.0,
        )
        self.intent_head = nn.Linear(semantic_hidden, 3)
        self.generation_embedding = nn.Embedding(vocab_size, embedding_dim)
        self.generation = nn.LSTM(
            embedding_dim, config["generation_hidden"],
            num_layers=config["generation_layers"], batch_first=True,
            dropout=dropout if config["generation_layers"] > 1 else 0.0,
        )
        self.generation_init_h = nn.Linear(
            semantic_hidden, config["generation_hidden"] * config["generation_layers"]
        )
        self.generation_init_c = nn.Linear(
            semantic_hidden, config["generation_hidden"] * config["generation_layers"]
        )
        self.generation_head = nn.Linear(config["generation_hidden"], vocab_size)
        self.ctc_loss = nn.CTCLoss(blank=self.blank_id, zero_infinity=True)

    def acoustic(self, features, lengths):
        packed = nn.utils.rnn.pack_padded_sequence(
            features, lengths.detach().cpu(), batch_first=True, enforce_sorted=False
        )
        encoded, _ = self.encoder(packed)
        encoded, _ = nn.utils.rnn.pad_packed_sequence(encoded, batch_first=True)
        logits = self.ctc_head(encoded)
        # CTC reserves the language-model control tokens for other tasks.
        logits[..., 1:4] = -1e4
        return F.log_softmax(logits, dim=-1)

    def semantic_pool(self, embeddings, lengths, confidence=None):
        packed = nn.utils.rnn.pack_padded_sequence(
            embeddings, lengths.detach().cpu(), batch_first=True, enforce_sorted=False
        )
        output, _ = self.semantic(packed)
        output, _ = nn.utils.rnn.pad_packed_sequence(output, batch_first=True)
        mask = (torch.arange(output.size(1), device=output.device)[None, :] <
                lengths[:, None]).to(output.dtype)
        weights = mask if confidence is None else mask * confidence[:, :output.size(1)]
        pooled = (output * weights[..., None]).sum(dim=1) / weights.sum(dim=1).clamp_min(1e-7)[:, None]
        return pooled

    def decoder_state(self, context):
        batch = context.size(0)
        layers = self.config["generation_layers"]
        hidden = self.config["generation_hidden"]
        h = self.generation_init_h(context).reshape(batch, layers, hidden).transpose(0, 1).contiguous()
        c = self.generation_init_c(context).reshape(batch, layers, hidden).transpose(0, 1).contiguous()
        return h, c

    def generate_logits(self, context, decoder_input):
        embedding = self.generation_embedding(decoder_input)
        output, _ = self.generation(embedding, self.decoder_state(context))
        return self.generation_head(output)

    def forward(self, batch, loss_weights=None):
        device = batch["features"].device
        lengths = batch["feature_lengths"]
        log_probs = self.acoustic(batch["features"], lengths)
        embeddings, confidence = self.bridge(log_probs)
        context = self.semantic_pool(embeddings, lengths, confidence)
        intent_logits = self.intent_head(context)
        losses = {}
        if batch.get("ctc_targets") is not None:
            losses["ctc"] = self.ctc_loss(
                log_probs.transpose(0, 1), batch["ctc_targets"],
                lengths, batch["ctc_target_lengths"]
            )
        valid = batch.get("intent", torch.full((context.size(0),), -1, device=device)) >= 0
        if valid.any():
            losses["intent"] = F.cross_entropy(intent_logits[valid], batch["intent"][valid])
        if batch.get("decoder_target") is not None:
            generation_logits = self.generate_logits(context, batch["decoder_input"])
            pad_id = 1
            if (batch["decoder_target"] != pad_id).any():
                losses["generation"] = F.cross_entropy(
                    generation_logits.reshape(-1, generation_logits.size(-1)),
                    batch["decoder_target"].reshape(-1), ignore_index=pad_id
                )
        else:
            generation_logits = None
        weights = loss_weights or {"ctc": 0.60, "intent": 0.25, "generation": 0.15}
        weighted = [weights[key] * value for key, value in losses.items()]
        total = sum(weighted) if weighted else log_probs.sum() * 0.0
        return {
            "log_probs": log_probs,
            "confidence": confidence,
            "context": context,
            "intent_logits": intent_logits,
            "generation_logits": generation_logits,
            "losses": losses,
            "loss": total,
        }

    @torch.no_grad()
    def encode_candidate(self, token_ids, device):
        """Candidate transcriptions use the same semantic LSTM as audio posteriors."""
        if not token_ids:
            return None
        ids = torch.tensor([token_ids], device=device, dtype=torch.long)
        embeddings = self.bridge.embedding(ids)
        lengths = torch.tensor([len(token_ids)], device=device)
        return self.semantic_pool(embeddings, lengths)

    @torch.no_grad()
    def greedy_generate(self, context, vocab, max_tokens):
        batch_size = context.size(0)
        token = torch.full((batch_size, 1), vocab.to_id["<bos>"],
                           dtype=torch.long, device=context.device)
        state = self.decoder_state(context)
        generated = [[] for _ in range(batch_size)]
        finished = [False] * batch_size
        for _ in range(max_tokens):
            output, state = self.generation(self.generation_embedding(token), state)
            token = self.generation_head(output[:, -1]).argmax(dim=-1)[:, None]
            for idx, item in enumerate(token[:, 0].tolist()):
                if finished[idx]:
                    continue
                if item == vocab.to_id["<eos>"]:
                    finished[idx] = True
                else:
                    generated[idx].append(item)
            if all(finished):
                break
        return [vocab.decode(ids) for ids in generated]
